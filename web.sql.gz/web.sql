-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2022 at 02:14 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(3) NOT NULL,
  `Heading` varchar(256) NOT NULL,
  `Message` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `Heading`, `Message`) VALUES
(10, 'Exam Routine', 'Date:2022-12-2'),
(11, 'Sports Day', '17thdec-20thdec\r\nwear house dress'),
(12, 'Assignment due date', 'The assignment dead line is on 25May');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `cid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Duration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`cid`, `name`, `Duration`) VALUES
(125, 'Bsc.Computing', 3),
(202, 'MAD', 40),
(256, 'CS', 5),
(450, 'BBA', 5);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `did` int(11) NOT NULL,
  `Log` varchar(256) NOT NULL,
  `Date` date NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`did`, `Log`, `Date`, `uid`) VALUES
(6565, 'Today meeting at 6pm.', '2022-05-09', 909),
(6580, 'Notice!\r\nToday is holiday', '2022-12-12', 909),
(6581, 'Notice !\r\n26thdec deadline\r\nAssignment Submission', '2022-12-12', 1005),
(6582, 'page no. 3 question no. b', '2022-12-12', 101);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `mid` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `credit hours` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`mid`, `name`, `credit hours`, `course_id`, `staff_id`) VALUES
(520, 'Database', 20, 256, 202),
(2003, 'CSY2003', 120, 125, 1005),
(2021, 'Account', 40, 450, 1005);

-- --------------------------------------------------------

--
-- Table structure for table `timttable`
--

CREATE TABLE `timttable` (
  `id` int(11) NOT NULL,
  `Time` varchar(10) NOT NULL,
  `MON` varchar(256) NOT NULL,
  `TUE` varchar(256) NOT NULL,
  `WED` varchar(256) NOT NULL,
  `THU` varchar(256) NOT NULL,
  `FRI` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timttable`
--

INSERT INTO `timttable` (`id`, `Time`, `MON`, `TUE`, `WED`, `THU`, `FRI`) VALUES
(4, '7am-8:30am', 'Math', 'Music', 'Nepali', 'Computer', 'Networking'),
(6, '9am-10am', 'Computing', 'Software', 'Networking', 'Problem Solving', 'Maths'),
(9, '12-12:30am', 'Computer', 'Network', 'MAD', 'Problem', 'Library'),
(10, '12-2pm', 'Computer', 'Network', 'MAD', 'Problem', 'Library');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(11) NOT NULL,
  `u_name` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `contact` varchar(256) NOT NULL,
  `role` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL DEFAULT '2021'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `u_name`, `address`, `contact`, `role`, `password`) VALUES
(101, 'Panas Pokharel', 'Dallu', '9808116701', 'student', '1234'),
(202, 'Raj Singh', 'Jorpati', '5668710357', 'teacher', '2021'),
(909, 'Adam Blake', 'Baneswor', '5655556', 'admin', '2021'),
(1005, 'Reesav Rokka', 'sundarijal', '9808116701', 'teacher', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`did`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`mid`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `timttable`
--
ALTER TABLE `timttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6583;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8787879;

--
-- AUTO_INCREMENT for table `timttable`
--
ALTER TABLE `timttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1006;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `uid` FOREIGN KEY (`uid`) REFERENCES `user` (`u_id`) ON DELETE CASCADE;

--
-- Constraints for table `module`
--
ALTER TABLE `module`
  ADD CONSTRAINT `course_id` FOREIGN KEY (`course_id`) REFERENCES `course` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `staff_id` FOREIGN KEY (`staff_id`) REFERENCES `user` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
